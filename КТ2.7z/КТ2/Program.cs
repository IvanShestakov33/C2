﻿using System;
internal class Program
{
    private static void Main(string[] args)
    {
       
        string foolName = "Василий Александрович Котов";
        byte age = 18;
        string Email = "Kotov18@mail.ru";
        int programmingScores = 80;
        int mathScores = 90;
        int physicsScores = 85;
        int totalScore = programmingScores + mathScores + physicsScores;
        int averageScore = (programmingScores + mathScores + physicsScores) / 3;


        string pattern = "\nФио: {0} \nВозраст: {1} \nEmail: {2} \nБаллы по Программированию: {3} \nБаллы по Математики: {4} \nБаллы по Физике: {5} \n Общий балл: {6} \nСредний балл {7}";

        Console.WriteLine(pattern,foolName,age,Email,programmingScores,mathScores,physicsScores,totalScore,averageScore);


    }
}