﻿using System;

namespace Matrices
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите количество строк в матрице: ");
            int rows = int.Parse(Console.ReadLine());

            Console.Write("Введите количество столбцов в матрице: ");
            int cols = int.Parse(Console.ReadLine());

            int[,] matrix = new int[rows, cols];
            Random rand = new Random();

            
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    matrix[i, j] = rand.Next(1,101);
                    Console.Write(matrix[i, j] + " ");
                }
                Console.WriteLine();
            }

           
            int sum = 0;
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    sum += matrix[i, j];
                }
            }

            Console.WriteLine("Сумма всех элементов: " + sum);
        }
    }
}