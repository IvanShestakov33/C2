﻿using System;

namespace LifeGame
{
    class Program
    {
        static void Main(string[] args)
        {
            int rows = 10;
            int cols = 10;
            bool[,] petriDish = new bool[rows, cols];
            Random rand = new Random();

            // Инициализация чашки Петри случайными бактериями
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    petriDish[i, j] = rand.Next(2) == 0 ? false : true;
                    Console.Write(petriDish[i, j] ? '*' : '-');
                }
                Console.WriteLine();
            }

            // Ход игры
            // Примем, что бактерия выживает, если у нее есть от 2 до 3 соседей

            bool[,] newPetriDish = new bool[rows, cols];
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++) ;
            }
        }
    }
}