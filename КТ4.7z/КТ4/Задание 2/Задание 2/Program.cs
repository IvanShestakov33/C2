﻿using System;



namespace Matrices
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите количество строк в матрице: ");
            int rows = int.Parse(Console.ReadLine());

            Console.Write("Введите количество столбцов в матрице: ");
            int cols = int.Parse(Console.ReadLine());

            int[,] matrix1 = new int[rows, cols];
            int[,] matrix2 = new int[rows, cols];
            int[,] resultMatrix = new int[rows, cols];
            Random rand = new Random();

            
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    matrix1[i, j] = rand.Next(0, 100);
                    Console.Write(matrix1[i, j] + " ");
                }
                Console.WriteLine();
            }

            Console.WriteLine();

           
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    matrix2[i, j] = rand.Next(0, 100);
                    Console.Write(matrix2[i, j] + " ");
                }
                Console.WriteLine();
            }

            Console.WriteLine();

            
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    resultMatrix[i, j] = matrix1[i, j] + matrix2[i, j];
                    Console.Write(resultMatrix[i, j] + " ");
                }
                Console.WriteLine();
            }
        }
    }
}