﻿using System;
using System.Text;
class Program
{
    static void Main(string[] args)
    {
        Console.Write("Введите число:");
        int i = Convert.ToInt32(Console.ReadLine());
        if (i % 2 == 0)
            Console.WriteLine("Число четное");
        else
            Console.WriteLine("Число нечётное");
    }

}





       
   
    
