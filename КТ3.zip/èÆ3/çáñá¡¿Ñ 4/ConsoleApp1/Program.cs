﻿using System;

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите длину последовательности:");
            int length = Convert.ToInt32(Console.ReadLine());

            int minElement = int.MaxValue;

            for (int i = 0; i < length; i++)
            {
                Console.WriteLine("Введите число:");
                int num = Convert.ToInt32(Console.ReadLine());

                if (num < minElement)
                {
                    minElement = num;
                }
            }

            Console.WriteLine($"Наименьший элемент в последовательности: {minElement}");
        }
    }
