﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {



        Console.WriteLine("Игра/ Угадай число");
        Random rand = new Random();
        int v = rand.Next(1, 101);
        int iiNumber = v;
        int count = 0;
        int userNumber;
        while(true)
        {
            Console.Write("\nВведите число:");
            count++;
            userNumber = Convert.ToInt32(Console.ReadLine());
            if (userNumber < iiNumber)
            {
                Console.WriteLine("Загаданое число меньше.Поробуйте еще раз!");
            }
            else if (userNumber > iiNumber)
            {
                Console.WriteLine("Загаданое число больше. Попробуйте еще раз!");
            }
            else
            {
                Console.WriteLine($" Поздравляем! Вы угадали! Число попыток:{count}");
                Console.ReadKey();
                break;
            }
        }
    }
}

