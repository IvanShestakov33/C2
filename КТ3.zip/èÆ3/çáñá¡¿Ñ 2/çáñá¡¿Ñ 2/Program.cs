﻿using System;

Console.Write("Введите число карт:");
int numberOfCard= int.Parse(Console.ReadLine());
int sum = 0;
for (int i = 1; i <= numberOfCard; i++)
{
    
    Console.Write("Введите наминал карт:\n");
    string handValue = Console.ReadLine();
    switch (handValue)
    {

        case "J":
            sum += 2;
            break;

        case "Q":
            sum += 3;
            break;

        case "K":
            sum += 4;
            break;
        case "5":
            sum += 5;
            break;
        case "6":
            sum += 6;
            break;
        case "7":
            sum += 7;
            break;
        case "8":
            sum += 8;
            break;
        case "9":
            sum += 9;
            break;
        case "10":
            sum += 10;
            break;
        case "T":
            sum += 11;
            break;
        default:

            Console.WriteLine("Допусимы значения: J, Q, K, T, 5-10");
            i--;
            break;
    }
}
Console.WriteLine("Сумма карт на руках:" + sum);
Console.ReadLine();

